package threadDemo2;
import java.lang.Runnable;

public class threadDemoLamda {
	
	public static void main(String[] args) throws Exception
	{		
		Thread t1 = new Thread(() ->
		{
			int b = 100;
			for(int i=1;i<=5;i++)
			{
				System.out.println(b);
				b = b+1;
				try {Thread.sleep(1000);} catch(Exception e) {}
			}
		});
		Thread t2 = new Thread(() ->
				{
			int a = 10;
			for(int i=1;i<=5;i++) 
			{
				System.out.println(a);
				a = a + 1;
				try {Thread.sleep(1000);} catch(Exception e) {}
			}
				});
		t1.start();
		try {Thread.sleep(10);} catch(Exception e) {}
		t2.start();
		
		
		
		System.out.println("Okay Bye...");
		
		System.out.println(t1.isAlive()); //Dedacte t1 is runing state or not
		
		t1.join(); //wait for the thread complete the process then only go for next line
		t2.join(); // wait for the complete the for loop
		
		System.out.println(t1.isAlive()); // Dedacte t1 is runing state or not
		
		System.out.println("Truly Bye...");
	}
}


