package threadDemo2;


public class threadDemo2 {	
	public static void main(String[] args) 
	{
		Runnable obj1 = new Hi();
		Runnable obj2 = new Hello();
		
		Thread t1 = new Thread(obj1);
		Thread t2 = new Thread(obj2);
		
		t1.start();
		try {Thread.sleep(10);} catch(Exception e) {}
		t2.start();
	}
}

class Hello implements Runnable
{
	
int b = 100;
	public void run() 
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println(b);
			b = b+1;
			try {Thread.sleep(1000);} catch(Exception e) {}
		}
	}
}

class Hi implements Runnable
{	
int a = 10;
	public void run() 
	{
		for(int i=1;i<=5;i++) 
		{
			System.out.println(a);
			a = a + 1;
			try {Thread.sleep(1000);} catch(Exception e) {}
		}
	}
}
